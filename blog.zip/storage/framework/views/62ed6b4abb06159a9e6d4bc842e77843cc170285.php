<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">

  <title>Oferta Academica</title>

  <link href="assets/img/favicon.png" rel="icon">

  <link href="<?php echo e(asset('templates/Portfolio/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('templates/Portfolio/assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('templates/Portfolio/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('templates/Portfolio/assets/vendor/venobox/venobox.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('templates/Portfolio/assets/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('templates/Portfolio/assets/vendor/aos/aos.css')); ?>" rel="stylesheet">

  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('templates/Portfolio/assets/css/style.css')); ?>" rel="stylesheet">

</head>
<body>

  <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>

  <header id="header">
    <div class="d-flex flex-column">
      <div class="profile">
        <img src="<?php echo e(URL::asset('img/LOGOTIPO_BLANCO.png')); ?>">
      </div>
      <nav class="nav-menu">
        <ul>
          <li class="active"><a href="<?php echo e(route('cursos')); ?>"><i class="bx bx-home"></i> <span>OFERTA ACADEMICA</span></a></li>
          <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#<?php echo e($det->tipo_oferta_min); ?>"><i class="bx bx-right-arrow-alt"></i> <span><?php echo e($det->tipo_oferta); ?></span></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <li><a href="https://egpp.gob.bo/"><i class="bx bx-exit"></i> <span>VOLVER A LA PAGINA WEB</span></a></li>
          
        </ul>
      </nav>
      <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>

    </div>
  </header>

  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1>OFERTA ACADEMICA</h1>
      <p><span class="typed" data-typed-items="DIPLOMADOS, CURSOS CORTOS, CURSOS ESPECIALIZADOS, IDIOMAS"></span></p>
    </div>
  </section>

  <main id="main">
  <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det_tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section id="<?php echo e($det_tipo->tipo_oferta_min); ?>" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2><?php echo e($det_tipo->tipo_oferta); ?></h2>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li onclick="filtros('<?php echo e($det_tipo->tipo_oferta_min); ?>','<?php echo e($det_tipo->tipo_oferta_min); ?>')" class="filter-active">TODOS</li>
              <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($det_tipo->tipo_oferta == $det_area->tipo_oferta): ?>
                      <li onclick="filtros('<?php echo e($det_area->tipo_oferta_min); ?>','<?php echo e($det_area->area_curso_min); ?>')"><?php echo e($det_area->area_curso); ?></li>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container">
        <?php $__currentLoopData = $cusos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det_cuso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($det_tipo->tipo_oferta == $det_cuso->tipo_oferta): ?>
            <div class="col-lg-4 col-md-6 portfolio-item <?php echo e($det_cuso->tipo_oferta_min); ?> <?php echo e($det_cuso->area_curso_min); ?>">
              <div class="portfolio-cuadro">
                <!-- <?php echo e($det_cuso->link_imagen); ?> -->
                <?php if($det_cuso->link_imagen!=''): ?>
                  <img src="<?php echo e($det_cuso->url_imagen); ?>" class="img-fluid" alt="">
                <?php else: ?>
                  <img src="<?php echo e(URL::asset('img/generico.png')); ?>" class="img-fluid" alt="">
                <?php endif; ?>
                <div class="about">
                    <div class="col-lg-12 content">
                      <div class="text-center">
                        <strong> <?php echo e($det_cuso->curso); ?> </strong>
                        <p> <small><?php echo e($det_cuso->area_curso); ?></small> </p>  
                      </div>
                      <hr>
                      <div class="row">
                        <ul>
                          <li><i class="fa fa-calendar"></i> <strong>Incio:</strong> <?php echo e($det_cuso->fec_ini_curso); ?></li>
                          <li><i class="fa fa-clock-o"></i> <strong>Horarios:</strong> <?php echo e($det_cuso->horarios); ?></li>
                          <li><i class="fa fa-book"></i> <strong>Carga Horaria:</strong> <?php echo e($det_cuso->carga_horaria); ?> Horas</li>
                          <li><i class="fa fa-credit-card"></i> <strong>Inversion:</strong> Bs.  <?php echo e($det_cuso->costo_curso); ?></li>
                          <small>
                          <li  class="text-danger"><i class="fa fa-calendar fa-small text-danger"></i> <strong>Limite de inscripcion:</strong> <?php echo e($det_cuso->fec_fin_preins); ?></li>
                          <li><i class="fa fa-user"></i> <strong>Coordinador:</strong> <?php echo e($det_cuso->coordinador); ?></li>
                          <li><i class="fa fa-at"></i> <strong>Correo:</strong> <?php echo e($det_cuso->email_infor); ?></li>
                          </small>
                        </ul>
                      </div>
                      <a target="_blank" rel="noopener noreferrer" href="<?php echo e($det_cuso->url_gesac); ?>" class="btn btn-miboton btn-block" role="button">Detalle e Inscripcion</a>
                    </div>
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/waypoints/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/counterup/counterup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/venobox/venobox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/typed.js/typed.min.js')); ?>"></script>
  <script src="<?php echo e(asset('templates/Portfolio/assets/vendor/aos/aos.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('templates/Portfolio/assets/js/main.js')); ?>"></script>

  <script type="text/javascript">
    

function filtros(a,b) {
  $('.'+a).hide();
  $('.'+a+'.'+b).show();
};
  
 
  
  </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/cursos.blade.php ENDPATH**/ ?>